function localCounter = incLocal(lastCounter)
% increment last counter
localCounter = lastCounter + 1;
end