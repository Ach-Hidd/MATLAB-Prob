function incGlobal
global globalCounter
globalCounter = globalCounter + 1;
end